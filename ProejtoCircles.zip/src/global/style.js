import styled from "styled-components";

export const Wrapper = styled.div`
background-color: #E4E4E4;
min-height: 100vh;
padding: 0px;
margin: 0px;
display: grid;
grid-template-columns: 1fr 4fr;
grid-template-rows: 1fr;

`